<!doctype html>
<html lang="en">

<head>
	<!-- Required meta tags -->
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<meta name="description" content="Adnan">
  	<meta name="keywords" content="Adnan">
  	<meta name="author" content="Muhammad Adnan Zainul Muttaqin">
	<!-- Bootstrap CSS -->
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" integrity="sha384-WskhaSGFgHYWDcbwN70/dfYBj47jz9qbsMId/iRN3ewGhXQFZCSftd1LZCfmhktB" crossorigin="anonymous">
	<link rel="stylesheet" href="style/css/mbarepe.css">
	<link href="style/images/mbarepe.png" rel="icon">
	<title>MBAREPE.com : Disini sangat dingin.</title>
	<link href="https://fonts.googleapis.com/css?family=Encode+Sans+Condensed" rel="stylesheet"> 
	<link href="style/fontawesome/web-fonts-with-css/css/fontawesome-all.css" rel="stylesheet">
</head>
<body>
	<section id="main">
		<article class="container-fluid">
			<div class="row">
				<div class="col-sm-12">
					<img class="mx-auto d-block" src="style/images/adnan.jpg">
				</div>
			</div>
			<div class="row">
				<div class="col-sm-12">
					<h2>"Disini sangat dingin, bisakah Kau bersamaku?"</h2>
					<h1>- MBAREPE -</h1>
				</div>
			</div>
			<div class="row">
				<div class="col-sm-12">
					<a href="https://www.facebook.com/mazmsnsc" target="_blank"><i class="fab fa-facebook-f"></i></a>
					<a href="https://github.com/adnanm74" target="_blank"><i class="fab fa-github"></i></a>
					<a href="https://www.linkedin.com/in/muhammad-adnan-48a332163/" target="_blank"><i class="fab fa-linkedin"></i></a>
					<a href="https://www.twitter.com/adnansnsc" target="_blank"><i class="fab fa-twitter"></i></a>
					<a href="https://www.youtube.com/" target="_blank"><i class="fab fa-youtube"></i></a>
				</div>
			</div>
		</article>
	</section>

	<!-- Optional JavaScript -->
	<!-- jQuery first, then Popper.js, then Bootstrap JS -->
	<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js" integrity="sha384-smHYKdLADwkXOn1EmN1qk/HfnUcbVRZyYmZ4qpPea6sjB/pTJ0euyQp0Mk8ck+5T" crossorigin="anonymous"></script>
	<script src="style/js/mbarepe.js"></script>
</body>
</html>